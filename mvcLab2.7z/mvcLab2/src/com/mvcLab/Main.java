package com.mvcLab;

/**
 * Created by student on 23.05.2018.
 */
public class Main {
    public static void main(String args[]){
        Model model = new Model();
        model.start();
    }
}
