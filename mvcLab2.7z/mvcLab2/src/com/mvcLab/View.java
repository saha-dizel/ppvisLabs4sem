package com.mvcLab;

/**
 * Created by student on 23.05.2018.
 */
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.SWT;

public class View {
    public void mainView(){
        Display mainDisplay = new Display();
        Shell mainShell = new Shell(mainDisplay);

        GridLayout mainGL = new GridLayout(2, true);
        mainGL.marginBottom = 20;
        mainGL.marginTop = 15;
        mainGL.verticalSpacing = 10;
        mainGL.marginWidth = 10;

        mainShell.setLayout(mainGL);

        GridData mainGD = new GridData(SWT.FILL, SWT.FILL, true, false);
        mainGD.horizontalSpan = 2;

        //'ere goes buttons
        Button create = new Button(mainShell, SWT.PUSH);
        create.setText("Create array");
        create.setLayoutData(mainGD);
        Button search = new Button(mainShell, SWT.PUSH);
        search.setText("Find element in array");
        search.setLayoutData(mainGD);
        Button delete = new Button(mainShell, SWT.PUSH);
        delete.setText("Delete element from array");
        delete.setLayoutData(mainGD);
        Button save = new Button(mainShell, SWT.PUSH);
        save.setText("Save array");
        save.setLayoutData(mainGD);
        Button load = new Button(mainShell, SWT.PUSH);
        load.setText("Load array");
        load.setLayoutData(mainGD);

        mainShell.open();
        while(!mainShell.isDisposed()) {
            if (!mainDisplay.readAndDispatch())
                mainDisplay.sleep();
        }
        mainDisplay.dispose();
    }

    public void createView(){
        Display createDisplay = new Display();
        Shell createShell = new Shell(createDisplay);

        Label createFIO = new Label(createShell, SWT.NONE);
        createFIO.setText("Full name");
        createFIO.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        Text inputCreateFIO = new Text(createShell, SWT.NONE);
        inputCreateFIO.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
        Label createAddress = new Label(createShell, SWT.NONE);
        createAddress.setText("Address");
        createAddress.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        Text inputCreateAddress = new Text(createShell, SWT.NONE);
        inputCreateAddress.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
        Label createMobile = new Label(createShell, SWT.NONE);
        createMobile.setText("Home phone number");
        createMobile.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        Text inputCreateMobile = new Text(createShell, SWT.NONE);
        inputCreateMobile.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
        Label createHome = new Label(createShell, SWT.NONE);
        createHome.setText("Mobile phone number");
        createHome.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        Text inputCreateHome = new Text(createShell, SWT.NONE);
        inputCreateHome.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 2, 1));
        Button createAddStop = new Button(createShell, SWT.PUSH);
        createAddStop.setText("Add and end");
        createAddStop.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
        Button createAddContinue = new Button(createShell, SWT.PUSH);
        createAddContinue.setText("Add and repeat");
        createAddContinue.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));

        createShell.open();
        while(!createShell.isDisposed()) {
            if (!createDisplay.readAndDispatch())
                createDisplay.sleep();
        }
        createDisplay.dispose();
    }

    public void searchView(){

    }

    public void deleteView(){

    }
}
