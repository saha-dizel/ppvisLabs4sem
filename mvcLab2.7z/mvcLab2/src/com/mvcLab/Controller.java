package com.mvcLab;

/**
 * Created by student on 23.05.2018.
 */
public class Controller {
}
